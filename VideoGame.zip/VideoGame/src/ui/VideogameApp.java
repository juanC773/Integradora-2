package ui;

import java.util.Scanner;
import model.VideoGame;

public class VideogameApp {

	public static Scanner lector = new Scanner(System.in);

	// Relations
	private VideoGame game;

	// Methods

	/**
	 * Contains the game constructor, invokes level creation, and creates the
	 * controller.
	 */
	public VideogameApp() {
		game = new VideoGame();
		game.addLevel(0, 0, 0, 0);
	}

	/**
	 * name: main
	 * It is the source of everything, where the program is executed.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		VideogameApp objMain = new VideogameApp();
		objMain.menu();

	}

	public void menu() {

		int option = 0;

		while (option != 13) {
			System.out.println(" == Menu == ");
			System.out.println("1. Create a Player." ); 
			System.out.println("2. Register enemy to a level."); 
			System.out.println("3. Register treasure to a level."); 
			System.out.println("4. Modify a player's score.");  
			System.out.println("5. Increase level for a player."); 
			System.out.println("6. Report the treasures and enemies of a given level."); 
			System.out.println("7. Report the amount found of a treasure in all levels.");
			System.out.println("8. Report the amount found of an enemy type in all levels."); 
			System.out.println("9. Report the most repeated treasure in all levels.");
			System.out.println("10. Inform the enemy that gives the highest score and the level where it is located."); 
			System.out.println("11. Report the number of consonants found in the names of enemies in the game."); 
			System.out.println("12. Inform the top 5 of the players according to the score."); 
			System.out.println("13. Exit menu.");
             
			
			option = lector.nextInt();
			lector.nextLine();

			switch (option) {
				case 1:
					registerPlayer();
					break;

				case 2:
					registerEnemyToLevel();
					break;

				case 3:
					registerTreasureToLevel();
					break;

				case 4:
					modifyScorePlayer();
					break;

				case 5:
					increaseLevel();
					break;

				case 6:
					enemyAndTreasureOfALevel();
					break;

				case 7:
	                treasuresType();
					break;

				case 8:
					typeOfEnemy();
					break;

				case 9:
					
					break;

				case 10:
					System.out.println(game.enemyWithTheHighestScore());
					break;

				case 11:
					System.out.println(game.getAllConsonants());
					break;

				case 12:
					System.out.println(game.calculateTop5Players());
					break;


				case 13:
					System.out.println("Exiting the menu."); 
				    break;

				default:
					System.out.println("Option out of range.");
					break;
			}
		}

	}

	 

	 /**
	  * It stores the data entered by the user to create part of the players.
	  */
	public void registerPlayer() {

		System.out.println("Type the nickname");
			String nickname = lector.nextLine();

		System.out.println("Type the name of the player");
			String name = lector.nextLine();

		System.out.println(game.addPlayer(nickname, name));
	}

	
	 // It stores the data that the user enters to create part of the enemies.
	 
	public void registerEnemyToLevel() {

		System.out.println("Type the name of the enemy");
			String name = lector.nextLine();

		System.out.println("Enter the type of enemy: \n1.OGRE \n2.BOSS\n 3.MAGIC \n 4.ABSTRACT ");
			int option = lector.nextInt();
			lector.nextLine();

		System.out.println("Type the level to be assigned");
			int levelToAssign = lector.nextInt();
			lector.nextLine();

		System.out.println("Type the score that adds to the player");
			int sumEnemyscore = lector.nextInt();
			lector.nextLine();

		System.out.println("Type the score remaining to the player");
			int restScore = lector.nextInt();
			lector.nextLine();

		System.out.println(game.assignEnemyToLevel(name, option, levelToAssign, restScore, sumEnemyscore));

	}

 //It stores the data entered by the user to create part of the treasures.
	 
	 public void registerTreasureToLevel() {

		System.out.println("Type the name of the treasure");
			String nameTreasure = lector.nextLine();

		System.out.println("Type the amount of the treasure");
			int amountTreasure = lector.nextInt();
			lector.nextLine();

		System.out.println("Type the level to save it");
			int levelToAssignTreasure = lector.nextInt();
			lector.nextLine();

		System.out.println("Type the url of the image");
			String url = lector.nextLine();

		System.out.println("Type the score that adds the player");
			int sumScore = lector.nextInt();
			lector.nextLine();

		System.out.println(game.assignTreasureToLevel(nameTreasure, amountTreasure, levelToAssignTreasure, url, sumScore));
	 }
	
	  //Stores the data entered by the user to modify the player's score.
	 
	 public void modifyScorePlayer() {

		System.out.println("Type the nickname to the player");
			String nickNameToModify = lector.nextLine();

		System.out.println("Type the score to modify");
			int scoreToModify = lector.nextInt();
			lector.nextLine();

		System.out.println(game.modifyScorePlayer(nickNameToModify, scoreToModify));

	 }

	//Stores the data entered by the user to increase the player's level.

	 public void increaseLevel() {

		 System.out.println("Type the nickname to the player");
			String nickNameToChangeLevel = lector.nextLine();

			System.out.println(game.increaseLevelPlayer(nickNameToChangeLevel));
	 }


	
	  // Stores the data entered by the user to search for a level and display the
	  //level's enemies and treasures on the screen.

	 public void enemyAndTreasureOfALevel() {

		System.out.println("Type the level to search the enemies and treasures");
		 	int levelToSearchEandT = lector.nextInt();
		 	lector.nextLine();

		System.out.println(game.enemiesAndTreasuresOfALevel(levelToSearchEandT));
	 }


	
	 // save the name of the treasure to pass it to the controller

   public void treasuresType(){

	 System.out.println("Enter the name of the treasure");
	 String treasureToSearch = lector.nextLine();

	 System.out.println(game.allTreasuresOfAType(treasureToSearch));
   }

	public void typeOfEnemy() {

		System.out.println("Enter the type of enemy: \n1.OGRE \n2.BOSS\n 3.MAGIC \n 4.ABSTRACT ");
		int typeEnemy = lector.nextInt();

		System.out.println(game.getAllEnemiesType(typeEnemy));

	}


}
