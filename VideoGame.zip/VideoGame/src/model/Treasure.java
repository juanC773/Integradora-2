
package model;
public class Treasure {
    
	//Atributtes
	private int sumScore;
	private String nameTreasure;
	private String url;
	private double positionXtreasure;
	private double positionYtreasure;
	private int quantity;
	

	/**
	* name: Player
	* It is a constructor, who receives all the attributes to be able to create treasures.
	 * @param name Almacena el nombre del tesoro.
	 * @param quantity Almacena la cantidad del tesoro.
	 * @param url Almacena el url de la imagen del tesoro.
	 * @param sumScore Almacena los puntos que le otroga al jugador.
	 * @param positionXtreasure Almacena la posición del tesoro en X.
	 * @param positionYtreasure Almacena la posición del tesoro en Y
	 */
	public Treasure(String name,int quantity, String url,int sumScore, double positionXtreasure, double positionYtreasure) {
         this.nameTreasure=name;
		 this.quantity=quantity;
		 this.url=url;
		 this.sumScore=sumScore;
		 this.positionXtreasure=positionXtreasure;
		 this.positionYtreasure=positionYtreasure;

	}

     
	//Gets and sets
	// get: Used to request attributes from the class.
	// set: It has the function of modifying attributes to the class.

	public int getSumScore() {
		return sumScore;
	}

	public String getNameTreasure() {
		return nameTreasure;
	}


	public String getUrl() {
		return url;
	}


	public double getPositionXtreasure() {
		return positionXtreasure;
	}


	public double getPositionYtreasure() {
		return positionYtreasure;
	}


	public void setSumScore(int sumScore) {
		this.sumScore = sumScore;
	}


	public void setNameTreasure(String nameTreasure) {
		this.nameTreasure = nameTreasure;
	}


	public void setUrl(String url) {
		this.url = url;
	}


	public void setPositionXtreasure(double positionXtreasure) {
		this.positionXtreasure = positionXtreasure;
	}


	public void setPositionYtreasure(double positionYtreasure) {
		this.positionYtreasure = positionYtreasure;
	}
}