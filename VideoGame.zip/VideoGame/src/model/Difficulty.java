
package model;

// It is an enumeration which contains the possible difficulties of a level.
 public enum Difficulty {
	
	LOW, MEDIUM, HIGH;

 }