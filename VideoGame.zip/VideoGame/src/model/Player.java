
package model;
public class Player {
    
	//Atributtes
	private String nickName;
	private String name;
	private int lives=5;
	private Level level;
	private int scorePlayer=10;

	/**
	 * name: Player
	*It is a constructor, who receives all the attributes to be able to create players.
	* @param nickName String, which stores the player's nickname (must be different for all).
	* @param name Stores the player's name, which can be repeated.
	* @param lives Stores the lives of the player.
	* @param level Stores the player's level.
	* @param scorePlayer Stores the player's score.
	 */
	public Player(String nickName, String name, int lives, Level level, int scorePlayer) {
		this.nickName=nickName;
		this.name=name;
		this.lives=lives;
		this.level=level;
		this.scorePlayer=scorePlayer;
	}

    
	 
	//Gets and sets
	// get: Used to request attributes from the class.
	// set: It has the function of modifying attributes to the class.

	public String getNickName() {
		return nickName;
	}

	public String getName() {
		return name;
	}

	public int getLives() {
		return lives;
	}

	public Level getLevel() {
		return level;
	}

	public int getScorePlayer() {
		return scorePlayer;
	}

	public void setNickName(String nickName) {
		this.nickName = nickName;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setLives(int lives) {
		this.lives = lives;
	}

	public void setLevel(Level level) {
		this.level = level;
	}

	public void setScorePlayer(int scorePlayer) {
		this.scorePlayer = scorePlayer;
	}
}