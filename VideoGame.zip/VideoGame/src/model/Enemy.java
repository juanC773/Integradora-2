
package model;
public class Enemy {
     
	//Atributtes
	private int restScore;
	private String idEnemy;
	private int sumScore;
	private double positionXenemy;
	private double positionYenemy;
	private TypeEnemy tpEnemy;
	
	/**
	 * name: Enemy
	 *It is a constructor, which receives all the attributes to be able to create enemies.
    * @param idEnemy String, which contains the unique name of each enemy.
	* @param option Stores the enemy type option.
	* @param restScore Stores the score that the enemy has subtracted from the player.
	* @param sumScore Stores the score that the enemy adds to the player.
	* @param positionXenemy Stores the position of the enemy in x.
	* @param positionYenemy Stores the position of the enemy in y.
	* @param typeEnemy Stores the type of enemy.
	*/
	public Enemy(String idEnemy, int option, int restScore,int sumScore, double positionXenemy, double positionYenemy, TypeEnemy typeEnemy) {
		this.idEnemy=idEnemy;
		this.restScore=restScore;
		this.sumScore=sumScore;
		this.positionXenemy=positionXenemy;
		this.positionYenemy=positionYenemy;
		this.tpEnemy=typeEnemy;	
	}
    
	 
	//Gets and sets
	// get: Used to request attributes from the class.
	// set: It has the function of modifying attributes to the class.

	public String getidEnemy(){
        return this.idEnemy;
	}

	public int getsumScore() {
		return this.sumScore;
	}

	public double getPositionXenemy() {
		return this.positionXenemy;
	}

	public double getPositionYenemy() {
		return positionYenemy;
		
	}

	public int getrestScore() {
		return restScore;	
	}

    public TypeEnemy getType() {
        return tpEnemy;
    }

}