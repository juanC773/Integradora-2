
package model;

/**
 * 
 */
public enum TypeEnemy {

	OGRO, JEFE, MAGICO, ABSTRACTO;

}