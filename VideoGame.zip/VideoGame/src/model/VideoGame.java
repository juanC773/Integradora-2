
package model;

import javax.annotation.processing.SupportedOptions;

public class VideoGame {

	// relations
	private Player[] players;
	private Level[] levels;

	/**
	 * name: VideoGame
	 * Contains the Video Game builder, level array and players.
	 */
	public VideoGame() {
		this.players = new Player[20];
		this.levels = new Level[10];

	}

	/**
	 * name: addPlayer
	 * Create the players and assign the players in a level depending on their
	 * initial score.
	 * 
	 * @param nickName is a String that stores the nickname of the players. <b>(the
	 *                 nickname cannot be repeated).</b>
	 * @param name     is a String that stores the name of the player.
	 * @return returns a message. which indicates if the player was created
	 *         correctly or not.
	 */
	public String addPlayer(String nickName, String name) {

		String message = "The player was created";
		Player objPlayer = searchPlayer(nickName);
		int lives = 5;
		int scorePlayer = 10;

		boolean stop = false;
		if (objPlayer == null) {
			objPlayer = new Player(nickName, name, lives, levels[0], scorePlayer);
			for (int i = 0; i < players.length && !stop; i++) {
				if (players[i] == null) {
					players[i] = objPlayer;
					stop = true;
				}
			}
		} else {
			message = "The nickname already exist";
		}

		return message;
	}

	/**
	 * name: searchPlayer
	 * The method looks for a player to verify that the nickname is not repeated,
	 * since there cannot be two same nicknames.
	 * 
	 * @param nickName The parameter contains the nickname to search for.
	 * @return Returns an object of type Player to be able to create the player in
	 *         addPlayer.
	 */
	public Player searchPlayer(String nickName) {
		Player objPlayer = null;
		boolean confirm = false;

		for (int i = 0; i < players.length && !confirm; i++) {
			if (players[i] != null) {
				if (players[i].getNickName().equalsIgnoreCase(nickName)) {
					objPlayer = players[i];

				}
			}
		}
		return objPlayer;
	}

	/**
	 * name: addLevel
	 * Create the levels
	 * 
	 * @param numid       contains the default identifier of the level.
	 * @param scoreNeed   contains the score needed by default to access the level.
	 * @param lotTreasure contains the level's default amount of treasure.
	 * @param lotEnemy    contains the level's default amount of enemies.
	 *                    <b>(by default they are null or zero)</b>
	 */
	public void addLevel(int numid, int scoreNeed, int lotTreasure, int lotEnemy) {

		for (int i = 0; i < levels.length; i++) {
			scoreNeed = i * 100;
			numid = i + 1;
			// Create the levels
			Level objLevel = new Level(numid, scoreNeed, lotTreasure, lotEnemy, null);
			levels[i] = objLevel;
		}

	}

	/**
	 * name: searchLevelOBJ
	 * Finds the typed level and returns it as an object
	 * 
	 * @param idLevel It receives from the ui the identifier of the level to look
	 *                for it. <b>(Levels must exist and the identifier must match
	 *                some level)</b>
	 * @return returns a LEVEL object
	 */
	public Level searchLevelOBJ(int idLevel) {

		Level objLevel = null;
		boolean confirm = false;
		for (int i = 0; i < levels.length && !confirm; i++) {
			if (levels[i] != null) {
				if (levels[i].getIdLevel() == idLevel) {
					objLevel = levels[i];
				}
			}
		}

		return objLevel;
	}

	/**
	 * name: searcPositionLevel
	 * Checks if the level with the identifier and returns the position of the level
	 * 
	 * @param idOfTheLevel Recibe un identificador de nivel del ui para verificar si
	 *                     el nivel existe. <b>(Deben existir niveles)</b>
	 * @return Returns the position of the typed level, as long as it exists.
	 */
	public int searchPositionLevel(int idOfTheLevel) {

		int positionLevel = -1;
		int finalPosition = 0;
		boolean confirm = false;
		for (int i = 0; i < levels.length && !confirm; i++) {
			if (levels[i] != null) {
				if (levels[i].getIdLevel() == idOfTheLevel) {
					int position = levels[i].getIdLevel();
					finalPosition = position + positionLevel;
				}
			}
		}
		return finalPosition;
	}

	/**
	 * name: assignTreasureToLevel
	 * Receives data from the ui to assign a level its respective treasure(s)
	 * 
	 * @param nameTreasure     It is the name of the treasure entered by the user.
	 * @param amountOfTreasure It is the amount of treasure to store in the level.
	 * @param levelToAssign    It is the level in which the treasure(s) will be
	 *                         stored.
	 * @param url              It is a String which contains the url of the treasure
	 *                         image.
	 *                         <b>It requires levels to exist</b> for its use.
	 */
	public String assignTreasureToLevel(String nameTreasure, int amountOfTreasure, int levelToAssign, String url,
			int sumScore) {

		String message = "";
		if (amountOfTreasure > 50) {
			message = "there can be no more than 50 treasures";
		} else if (amountOfTreasure <= 0) {
			message = "wrong amount";
		} else {
			int levelAssign = levelToAssign - 1;
			levels[levelAssign].addTreasure(nameTreasure, amountOfTreasure, levelAssign, url, sumScore);
			message = "were added successfully";
		}
		return message;
	}

	/**
	 * name: assignEnemyToLevel
	 * name: assignEnemyToLevel
	 * Assign the enemy to a level.
	 * 
	 * @param nameIdEnemy   Stores the identifier name of the enemy.
	 * @param option        Stores the option typed by the user to choose the type
	 *                      of enemy.
	 * @param assignToLevel Stores the level to assign the enemy
	 * @param restScore     Stores the enemy's remaining score for the player.
	 * @param sumEnemyscore Stores the enemy score that the player adds.
	 *                      <b>Levels must exist.</b>
	 * @return
	 */
	public String assignEnemyToLevel(String nameIdEnemy, int option, int assignToLevel, int restScore,
			int sumEnemyscore) {

		String message = "The enemy was assigned correctly";
		if (levels[assignToLevel - 1].searchEnemy(nameIdEnemy)) {
			levels[assignToLevel - 1].addEnemy(nameIdEnemy, option, restScore, sumEnemyscore);
		} else {
			message = "You can't add the same enemy to a level";
		}
		return message;
	}

	/**
	 * name: modifyScorePlayer.
	 * Modify the score of a given player.
	 * 
	 * @param nickNameToModify Stores the player's nickname to change their score.
	 * @param scoreToModify    Stores the new score which you want to assign to the
	 *                         player.
	 *                         <b>Players must exist.</b>
	 * @return Returns a message indicating whether the player's score could be
	 *         modified or not.
	 */
	public String modifyScorePlayer(String nickNameToModify, int scoreToModify) {

		String message = "Player not found";
		Player objPlayer = searchPlayer(nickNameToModify);
		if (objPlayer != null) {
			int score = objPlayer.getScorePlayer();
			objPlayer.setScorePlayer(scoreToModify + score);
			message = "It was successfully modified to: " + objPlayer.getScorePlayer();
		}
		return message;
	}

	/**
	 * name: increaseLevelPlayer
	 * Increases the level of a given player.1
	 * 
	 * @param nicknameToChangeLevel Stores the nickname of the player whose level
	 *                              you want to increase.
	 * @return Returns a message indicating whether the player's level could be
	 *         increased or not.
	 *         <b>Players and levels must exist.</b>
	 */
	public String increaseLevelPlayer(String nicknameToChangeLevel) {

		String message = "";
		Player objPlayer = searchPlayer(nicknameToChangeLevel);
		int level = objPlayer.getLevel().getIdLevel();
		if (objPlayer != null) {
			int scoreNeed = levels[level].getScoreNeed();
			int scorePlayer = objPlayer.getScorePlayer();
			if (scoreNeed > scorePlayer) {
				int scoreRq = scoreNeed - scorePlayer;
				message = "You can't pass the level, you need " + scoreRq + " of score";
			} else if (scoreNeed <= scorePlayer) {
				objPlayer.setLevel(levels[level]);
				message = "Congratulations, now you are on the level: " + objPlayer.getLevel().getIdLevel();
			}
		}
		return message;
	}

	/**
	 * name: enemies and treasures of a level
	 * Shows the levels and enemies of a given level by the user.
	 * 
	 * @param idLevel Stores the level that the user has typed.
	 * @return returns a message with the level's treasures and enemies.
	 */

	public String enemiesAndTreasuresOfALevel(int idLevel) {

		int level = searchPositionLevel(idLevel);
		String message = "The treasures are: " + levels[level].treasuresOfALevel() + "\n And the enemies are: "
				+ levels[level].enemiesOfALevel();

		return message;
	}

	/**
	 * name: getAllEnemiesType
	 * Go through the levels to find the enemies of a certain type.
	 * 
	 * @param type Stores the user option, which indicates the type of enemy you
	 *             want to count.
	 * @return Returns a message with the number of enemies of a given type.
	 *         <b>There must be enemies and levels recorded.</b>
	 */
	public String getAllEnemiesType(int type) {

		String message = "";
		int counterTypeEnemy = 0;
		TypeEnemy enemy = null;
		if (type == 1) {
			enemy = TypeEnemy.OGRO;

		} else if (type == 2) {
			enemy = TypeEnemy.JEFE;

		} else if (type == 3) {
			enemy = TypeEnemy.MAGICO;

		} else if (type == 4) {
			enemy = TypeEnemy.ABSTRACTO;
		}

		for (int i = 0; i < getLevels().length; i++) {
			counterTypeEnemy += getLevels()[i].countEnemiesByType(enemy);
		}
		message += "The amount of the enemy " + enemy + " is: " + counterTypeEnemy;
		return message;
	}

	/**
	 * name: allTreasuresOfAType
	 * counts all the treasures of a certain type.
	 * 
	 * @param nameofTreasure Stores the name of the treasure which you want to
	 *                       count.
	 * @return Returns a message with the amount of the typed treasure type
	 *         <b>There must be levels and treasures registered.</b>
	 */
	public String allTreasuresOfAType(String nameofTreasure) {

		int counterTreasures = 0;
		String message = "";
		for (int i = 0; i < levels.length; i++) {
			counterTreasures += getLevels()[i].counTATypeOfTreasure(nameofTreasure);
		}
		message += "The amount of " + nameofTreasure + " is: " + counterTreasures;
		return message;
	}

	/**
	 * name: enemyWithTheHighhestScore
	 * Look for the enemy that has the score that gives the player the most points.
	 * 
	 * @return Returns a message indicating the enemy with the most points added to
	 *         the player or that there are no enemies found.
	 *         <b>There must be levels registered.</b>
	 */
	public String enemyWithTheHighestScore() {
		int enemyPosition = -1;
		int position = -1;
		int minimum = 0;
		int maximum = 0;
		for (int i = 0; i < getLevels().length; i++) {
			for (int j = 0; j < getLevels()[0].getEnemies().length; j++) {

				if (getLevels()[i].getEnemies()[j] != null) {
					minimum = getLevels()[i].getEnemies()[j].getsumScore();
					if (minimum > maximum) {
						maximum = minimum;
						position = i;
						enemyPosition = j;
					}
				}
			}
		}
		String message = "no enemies found";
		if (enemyPosition != -1 && position != -1) {
			message = "The enemy that gives the most points is "
					+ getLevels()[position].getEnemies()[enemyPosition].getidEnemy() + " of type "
					+ getLevels()[position].getEnemies()[enemyPosition].getType() + " on the level " + (position + 1)
					+ "\n" +
					"His points are: " + getLevels()[position].getEnemies()[enemyPosition].getsumScore();
		}
		return message;
	}

	/**
	 * name: getAllConsonants
	 * counts the number of consonants in enemy names.
	 * 
	 * @return Returns the number of consonants that the names of the enemies have.
	 *         <b>Enemies and levels must be registered.</b>
	 */
	public String getAllConsonants() {
		String message = "";
		int counter = 0;
		String enemyName = "";
		String consonants = "bcdfghjklmnpqrstvwxyz";

		for (int i = 0; i < getLevels().length; i++) {
			for (int j = 0; j < getLevels()[0].getEnemies().length; j++) {
				if (getLevels()[i].getEnemies()[j] != null) {
					enemyName = getLevels()[i].getEnemies()[j].getidEnemy();
					for (int k = 0; k < consonants.length(); k++) {
						for (int l = 0; l < enemyName.length(); l++) {
							if (enemyName.charAt(l) == consonants.charAt(k)) {
								counter++;
							}

						}
					}
				}
			}

		}
		return message = "In the game the enemies have a total of " + counter + " consonants in their names";
	}

	/**
	 * name: calculateTop5Players
	 * calculates the top 5 players with the highest score.
	 * 
	 * @return Returns a message with the top 5 players with the highest score or
	 *         that there are no registered players.
	 */
	public String calculateTop5Players() {

		Player[] playersTop5 = new Player[5];
		StringBuilder message = new StringBuilder("There are no registered players.");

		for (Player player : players) {
			if (player != null) {
				if (playersTop5[0] == null) {
					playersTop5[0] = player;
				} else {
					boolean swapped = false;
					for (int i = 0; i < playersTop5.length && !swapped; i++) {
						if (playersTop5[i] == null) {
							playersTop5[i] = player;
							swapped = true;
						} else if (playersTop5[i].getScorePlayer() < player.getScorePlayer()) {
							for (int k = playersTop5.length - 1; k > i; k--) {
								playersTop5[k] = playersTop5[k - 1];
							}
							playersTop5[i] = player;
							swapped = true;
						}
					}
				}
			}
		}
		if (playersTop5[0] != null) {
			message = new StringBuilder("The top 5 :\n ");
			for (int i = 0; i < playersTop5.length; i++) {
				if (playersTop5[i] != null) {
					message.append(i).append(1).append(". ").append(playersTop5[i].getNickName()).append(" with ")
							.append(playersTop5[i].getLives()).append(" score.\n ");
				}
			}
		}
		return message.toString();
	}

	// gets
	// get: Used to request attributes from the class.
	public Level[] getLevels() {
		return levels;
	}

	public Player[] getPlayers() {
		return players;
	}
}