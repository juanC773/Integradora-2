
package model;

import java.util.Random;

public class Level {

	// Atributtes
	private int lotTreasure;
	private int lotEnemy;
	private Difficulty difficulty;
	private int scoreNeed;
	private int idLevel;

	// relations
	private Treasure[] treasures;
	private Enemy[] enemies;
	private TypeEnemy enemy;

	/**
	 * name: Level
	 * It is a constructor, who receives all the attributes to be able to create
	 * levels.
	 * 
	 * @param idLevel     Stores the identifier of the level.
	 * @param scoreNeed   Stores the score required to enter the level.
	 * @param lotTreasure Stores the amount of treasure in the level.
	 * @param lotEnemy    Stores the number of enemies in the level.
	 * @param difficulty  Stores the difficulty of the level.
	 */
	public Level(int idLevel, int scoreNeed, int lotTreasure, int lotEnemy, Difficulty difficulty) {
		this.idLevel = idLevel;
		this.scoreNeed = scoreNeed;
		this.lotTreasure = lotTreasure;
		this.lotEnemy = lotEnemy;
		treasures = new Treasure[50];
		enemies = new Enemy[25];
	}

	/**
	 * name: addEnemy
	 * create the enemy.
	 * 
	 * @param idEnemy       Stores the identifier name of the enemy.
	 * @param option        Stores the option typed by the user to choose the type
	 *                      of enemy.
	 * @param restScore     Stores the score taken from the player.
	 * @param sumEnemyscore Stores the score that the player adds.
	 *                      <b>Levels must exist and have correctly received the ui
	 *                      data</b>
	 */
	public void addEnemy(String idEnemy, int option, int restScore, int sumEnemyscore) {

		boolean stop = false;
		TypeEnemy enemy = null;

		if (option == 1) {
			enemy = TypeEnemy.OGRO;

		} else if (option == 2) {
			enemy = TypeEnemy.JEFE;

		} else if (option == 3) {
			enemy = TypeEnemy.MAGICO;

		} else if (option == 4) {
			enemy = TypeEnemy.ABSTRACTO;
		}

		double positionXenemy = createdRandomPosition();
		double positionYenemy = createdRandomPosition();

		for (int j = 0; j < enemies.length && !stop; j++) {

			Enemy objEnemy = new Enemy(idEnemy, option, restScore, sumEnemyscore, positionXenemy, positionYenemy,
					enemy);
			if (enemies[j] == null) {
				enemies[j] = objEnemy;

				stop = true;
			}
		}
	}

	/**
	 * name: createdRandomPosition
	 * Randomly assign HD format positions for enemies and treasures.
	 * 
	 * @return Returns a position in HD format (1280-720)
	 */
	public int createdRandomPosition() {
		int position = (int) (Math.random() * (1.280 - 720 + 1) + 720);
		return position;
	}

	/**
	 * name: addTreasure
	 * Create the treasure.
	 * 
	 * @param nameTreasure Stores the name of the treasure.
	 * @param amount       Stores the amount of the treasure.
	 * @param levelAssign  Stores the level to which the treasure corresponds.
	 * @param url          Stores the url of the treasure image.
	 *                     <b>Levels must exist and have correctly received the ui
	 *                     data</b>
	 */
	public boolean addTreasure(String nameTreasure, int amount, int levelAssign, String url, int sumScore) {

		double positionXtreasure = createdRandomPosition();
		double positionYtreasure = createdRandomPosition();
		boolean confirm = false;
		boolean stop = false;
		int addedQuantity = 0;

		for (int index = 0; index < amount; index++) {
			for (int j = 0; j < treasures.length && !stop; j++) {
				if (treasures[j] == null) {
					Treasure objTreasure = new Treasure(nameTreasure, amount, url, sumScore, positionXtreasure,
							positionYtreasure);
					treasures[j] = objTreasure;
					addedQuantity++;
				}
				if (addedQuantity > amount) {
					stop = true;
					confirm = true;
				}
			}

		}
		return confirm;
	}

	/**
	 * name: searchEnemy
	 * Look for an enemy.
	 * 
	 * @param idEnemy Stores the identifier name of the enemy to search for.
	 * @return Returns a boolean which confirms if the enemy which has been searched
	 *         for exists.
	 */
	public boolean searchEnemy(String idEnemy) {

		for (int i = 0; i < enemies.length; i++) {
			if (enemies[i] != null) {
				if (enemies[i].getidEnemy().equals(idEnemy)) {
					return false;
				}
			}
		}
		return true;
	}

	/**
	 * name: countEnemiesScore
	 * Calculates the difference of all the enemies with respect to the points that
	 * they add and subtract to the player.
	 * 
	 * @return Returns the score difference of all enemies that add to and subtract
	 *         from the player.
	 *         <b>Enemies must exist.</b>
	 */
	public int countEnemiesScore() {

		int scorePositive = 0;
		int scoreNegative = 0;
		int scoreFinal = 0;

		for (int i = 0; i < enemies.length; i++) {
			if (enemies[i] != null) {
				scorePositive += enemies[i].getsumScore();
				scoreNegative += enemies[i].getrestScore();
				scoreFinal = scorePositive - scoreNegative;
			}
		}
		return scoreFinal;
	}

	/**
	 * name: countTreasuresScore
	 * calculates the total score of all the treasures that are awarded to the
	 * player.
	 * 
	 * @return Returns the total score of all the treasures that give the player.
	 *         <b>There must be registered treasures.</b>
	 */
	public int countTresuresScore() {
		int finalScore = 0;
		for (int i = 0; i < treasures.length; i++) {
			if (treasures[i] != null) {
				finalScore += treasures[i].getSumScore();
			}
		}
		return finalScore;
	}

	/**
	 * name: countEnemiesByType
	 * counts all enemies of one enemy type
	 * 
	 * @param type Stores the type of enemy to start counting.
	 * @return Returns the number of enemies of the given type of enemy.
	 *         <b>Enemies must exist.</b>
	 */
	public int countEnemiesByType(TypeEnemy type) {

		int enemiesFound = 0;
		for (int i = 0; i < enemies.length; i++) {
			if (enemies[i] != null) {
				if (enemies[i].getType() == type) {
					enemiesFound++;
				}
			}
		}
		return enemiesFound;
	}

	/**
	 * name: countTATypeOfTreasure
	 * Count the amount of certain type of treasure.
	 * 
	 * @param nameTreasure Stores the type of treasure to be counted.
	 * @return Returns the number of treasures of the type of treasure that was
	 *         sought.
	 *         <b>There must be registered treasures.</b>
	 */
	public int counTATypeOfTreasure(String nameTreasure) {

		int treasuresFound = 0;

		for (int i = 0; i < treasures.length; i++) {
			if (treasures[i] != null) {
				if (treasures[i].getNameTreasure().equals(nameTreasure)) {
					treasuresFound++;
				}
			}
		}
		return treasuresFound;
	}

	// Calculate the difficulty of the level.
	public void calculateDifficulty() {

		Difficulty difficulty = Difficulty.LOW;
		if (countEnemiesScore() < countTresuresScore()) {
			difficulty = Difficulty.LOW;
		}
		if (countEnemiesScore() == countTresuresScore()) {
			difficulty = Difficulty.MEDIUM;
		}
		if (countEnemiesScore() > countTresuresScore()) {
			difficulty = Difficulty.HIGH;
		}

		setDifficulty(difficulty);
	}

	/**
	 * name: treasuresOfALevel
	 * Shows the treasures of a level.
	 * 
	 * @return Returns a message containing the treasures of each level.
	 */
	public String treasuresOfALevel() {
		String message = "";
		for (int i = 0; i < treasures.length; i++) {
			if (treasures[i] != null) {
				message += treasures[i].getNameTreasure() + " , ";
			}
		}
		return message;
	}

	/**
	 * name: enemiesOfALevel
	 * shows the enemies of a level
	 * 
	 * @return returns a message containing the enemies of each level.
	 */
	public String enemiesOfALevel() {
		String message = "";
		for (int i = 0; i < enemies.length; i++) {
			if (enemies[i] != null) {
				message += enemies[i].getidEnemy() + " , ";
			}
		}
		return message;
	}

	public int mostRepeatedTreasure(Treasure treasure) {

		int repeats = 0;
		for (int i = 0; i < treasures.length; i++) {
			if (treasures[i] != null) {
				if (treasures[i].equals(treasure)) {
					repeats++;
				}
			}
		}
		return repeats;
	}

	// Gets and sets
	// get: Used to request attributes from the class.
	// set: It has the function of modifying attributes to the class.

	public int getLotTreasure() {
		return lotTreasure;
	}

	public int getLotEnemy() {
		return lotEnemy;
	}

	public Difficulty getDifficulty() {
		return difficulty;
	}

	public int getScoreNeed() {
		return scoreNeed;
	}

	public int getIdLevel() {
		return idLevel;
	}

	public Enemy[] getEnemies() {
		return enemies;
	}

	public Treasure[] getTreasures() {
		return treasures;
	}

	public void setLotTreasure(int lotTreasure) {
		this.lotTreasure = lotTreasure;
	}

	public void setLotEnemy(int lotEnemy) {
		this.lotEnemy = lotEnemy;
	}

	public void setDifficulty(Difficulty difficulty) {
		this.difficulty = difficulty;
	}

	public void setScoreNeed(int scoreNeed) {
		this.scoreNeed = scoreNeed;
	}

	public void setIdLevel(int idLevel) {
		this.idLevel = idLevel;
	}
}