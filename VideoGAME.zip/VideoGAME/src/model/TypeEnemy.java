package model;

/**
 *
 * @author David
 */
public enum TypeEnemy {
    //se toman los nombres como una ennumeracion, ya que estos valores no se van a alterar
    OGRO, JEFE, MAGICO, ABSTRACTO;
}
