package model;

import java.util.Random;
import java.util.Scanner;

import javax.swing.text.Position;

/**
 *
 * @author David
 */
public class VideoGame {
    private Enemy[] valEnemigos;
    private int contTesoros;
    private Treasure[] valTreasures;
    private Level[] niveles;
    private Player[] jugadores;
    private String[] validadoStrings ;
     Scanner teclado = new Scanner(System.in);
    //
    public VideoGame() {
        this.niveles = new Level[10];
        this.jugadores = new Player[20];
        this.validadoStrings =  new  String[20];
        this.valTreasures =  new  Treasure[50];
        this.valEnemigos = new Enemy[25];
        inicializarVecValidar();
        llenarVectorNiveles();
        inicializarVecValidarEnemigos();
        //inicializarVecValidarTesoros();
    }
    //
    public void desplegarMenu(){
        int validar =0;
        boolean bandera = true ;

        do {
            System.out.println("------------------------------------------------");
            System.out.println("---------------------MENU-----------------------");
            System.out.println("------------------------------------------------");
            System.out.println("------------------------------------------------");
            System.out.println("1.--Crear un Jugador----------------------------");
            System.out.println("2.--Registrar enemigo---------------------------");
            System.out.println("3.--Registrar un tesoro-------------------------");
            System.out.println("4.--Modificar el puntaje de un jugador----------");
            System.out.println("5.--Incrementar nivel para un jugador-----------");
            System.out.println("6.--Informe de tesoros y enemigos de un nivel---");
            System.out.println("7.--Cantidad de un tesoro en total--------------");
            System.out.println("8.--Cantidad todal de un enemigo en todos los niveles----");
            System.out.println("9.--Tesoro mas repetido en todos los niveles-------------");
            System.out.println("10.-Enemigo con mayor puntaje y su nivel-----------------");
            System.out.println("11.-Cantidad de consonantes en los nombres de los enemigos------");
            System.out.println("12.-Top 5 jugadores---------------------------------------------");
            System.out.println("13.-Salir---------------------------------------------");
            validar =Integer.parseInt(teclado.nextLine());

            switch (validar) {
                case 1:

                    String varNombre,varNickname="";
                    System.out.println("Ingrese el nombre del jugador");
                    varNombre = teclado.nextLine();
                    System.out.println("Ingrese el NickName del jugador");
                    varNickname = teclado.nextLine();
                    System.out.println("Ingrese la posicion en la cual desea crear al jugador");
                    mostrarEspaciosLibres();
                    int posicion = Integer.parseInt(teclado.nextLine());
                    if (registrarJugador(varNombre, varNickname, posicion, jugadores) == true) {
                        System.out.println("el jugador  "+ varNickname +" se agrego con exito");
                        iniciarJugadoresPrimer(posicion);
                        System.out.println("---------------------------------------------------");
                    }else{
                        System.out.println("El jugador "+ varNickname + "no se pudo registrar en la posicion "+ posicion);
                        System.out.println("Por favor, verifique los datos (NickName y posicion) y vualva a intentarlo");
                    }

                    break;
                case 2:
                    if (contarEnemigos()>25) {
                        System.out.println("Ya ha llegado a la capacidad total de enemigos");
                    }else{
                        System.out.println("Ingrese el nivel en el que desea agregar el enemigo");
                        mostrarEspaciosLibresLevel();
                        posicion = Integer.parseInt(teclado.nextLine());
                        System.out.println("Ingrese el nombre del enemigo");
                        String prmNameEnemy = teclado.nextLine();
                        System.out.println("Ingrese el sub tipo del enemigo");
                        String prmSubTipo = teclado.nextLine();
                        System.out.println("Ingrese los puntos que suma al ganar");
                        int prmSumScore = Integer.parseInt(teclado.nextLine());
                        System.out.println("Ingrese los puntos que suma al perder");
                        int prmResScore = Integer.parseInt(teclado.nextLine());
                        if (niveles[posicion].registrarEnemigo(posicion, prmSubTipo, prmResScore, prmSumScore, tipoEnemigo(), prmNameEnemy)==true){
                            System.out.println("El enemigo "+prmNameEnemy+"se registro con exito en el nivel "+posicion);
                            System.out.print("estos son los enemigos registrados");
                            niveles[posicion].mostrarEspaciosLibresEnemigos();
                            teclado.nextLine();
                        }else{
                            System.out.println("El jugador "+ prmNameEnemy + "no se pudo registrar en la posicion "+ posicion);
                            System.out.println("Por favor, verifique los datos (NickName y posicion) y vualva a intentarlo");
                            teclado.nextLine();
                        }
                    }

                    break;
                case 3:
                    if (contarTesoros()<= 50) {
                        System.out.println("Ingrese el nivel en el que quiere agregar el tesoro");
                        mostrarEspaciosLibresLevel();
                        posicion = Integer.parseInt(teclado.nextLine());
                        System.out.println("Ingrese el nombre del tesoro");
                        String prmNombre = teclado.nextLine();
                        System.out.println("Ingrese la URL del tesoro");
                        String prmUrl = teclado.nextLine();
                        System.out.println("Ingrese los puntos del tesoro");
                        int prmPuntos = Integer.parseInt(teclado.nextLine());
                        if (niveles[posicion].registrarTesoros(prmUrl, prmNombre, prmPuntos, posicion)==true){
                            System.out.println("El tesoro " + prmNombre + "del nivel " + posicion);
                            System.out.println("Se registro correctamente, estos son los tesoros de este nivel");
                            System.out.println("");
                            niveles[posicion].mostrarEspaciosLibresTesoros();
                            teclado.nextLine();
                        }else{
                            System.out.println("El tesoro " + prmNombre + "del nivel " + posicion);
                            System.out.println("Se registro incorrectamente, estos son los tesoros de este nivel");
                            niveles[posicion].mostrarEspaciosLibresTesoros();
                            teclado.nextLine();
                        }

                    }else{
                        System.out.println("ya se han registrado todos los posibles tesoros");
                    }
                    break;
                case 4:
                    System.out.println("Ingrese el numero del jugador al que desea modificar el puntaje");
                    mostrarEspaciosLibres();
                    posicion = Integer.parseInt(teclado.nextLine());
                    System.out.println("ingrese el nuevo puntaje del jugador");
                    int prmPuntaje = Integer.parseInt(teclado.nextLine());
                    jugadores[posicion].setPuntajeInicial(prmPuntaje);
                    System.out.println("Puntaje modificado");
                    teclado.nextLine();
                    break;
                case 5:

                    mostrarEspaciosLibres();
                    System.out.println("ingrese la posicion del usuario que quiera subir de nivel");
                    int posicionJugador = Integer.parseInt(teclado.nextLine());
                    mostrarEspaciosLibresLevel();
                    System.out.println("ingrese la posicion del nivel al que quiera subir");
                    int posicionNivel = Integer.parseInt(teclado.nextLine());

                    IncrementarNivel(posicionNivel, posicionJugador);
                    System.out.println("asi quedo la tabla de posiciones");
                    mostrarJugadoresPorNivel();
                    break;
                case 6:
                    mostrarEspaciosLibresLevel();
                    System.out.println("Ingrese el nivel del el cual quuires saber los tesoros y enemigos");
                    posicion = Integer.parseInt(teclado.nextLine());
                    niveles[posicion].mostrarTesorosSeguido();
                    System.out.println("");
                    niveles[posicion].mostrarEnemigosSeguido();
                    teclado.nextLine();
                    break;
                case 7:
                    System.out.println("Ingrese el nombre del tesoro que desea contar");
                    String prmNombreTesoro = teclado.nextLine();
                    System.out.println("hay " + contarTotalTesoros(prmNombreTesoro + " tesoros con el nombre de  " +prmNombreTesoro));


                    break;
                case 8:
                    TypeEnemy tn = tipoEnemigo();
                    System.out.print("La cantidad de  " + tn + " es de  "+contarTotalTipoEnmigos(tn));

                    break;
                case 9:
                    System.out.println("el tesoro mas repetido es " + VecTesorosMasRepetidosPorNivel());
                    teclado.nextLine();
                    break;
                case 10:
                    VecEnemigoConMasPuntos();

                    System.out.println("El enemigo  "+masPuntosEnemigos().getNameEnemy()+" es el que mas puntos tiene y esta en el nivel "+uBicarNivel());
                    break;
                case 11:
                    System.out.println("hay " + contarConsonantes() +" en los nombres de los enemigos");
                    teclado.nextLine();
                    break;
                case 12:
                    topPlayers();
                    System.out.println("jugadores organizados");
                    mostrarEspaciosLibres();
                    teclado.nextLine();
                    break;
                case 13:
                    bandera=false;
                    break;






                default:
                    break;
            }

        } while (bandera);



    }
    public boolean validarJugadorExistente(String prmNickname) {

        for (int i = 0; i < validadoStrings.length; i++) {

                if (validadoStrings[i].equals(prmNickname)) {


                    return true;

                }



        }return false;







    }
    public void mostrarEspaciosLibres() {
        for (int i = 0; i < jugadores.length; i++) {
            if (jugadores[i]==null) {
                System.out.println("Posicion "+ i + ".------------------------vacio----------------------");

            }else{
                System.out.println("Posicion "+i+".--------------------"+jugadores[i].getNickname()+"---------------"+jugadores[i].getPuntajeInicial());
            }
        }
    }
    public boolean estaDisponibleJugador(Player[] vecValidar, int Posicion) {
        if (vecValidar[Posicion] == null) {
            return true;
        }else{
            return false;
        }
    }
    public boolean estaDisponibleNivel(Level[] vecValidar, int Posicion) {
        if (vecValidar[Posicion] == null) {
            return true;
        }else{
            return false;
        }
    }
    public boolean registrarJugador(String prmNombre, String prmNickName,int Posicion, Player[] vecPlayers) {
        if (estaDisponibleJugador(vecPlayers, Posicion)==true) {
            if (validarJugadorExistente(prmNickName)==false) {
                this.jugadores[Posicion] = new Player(prmNickName, prmNombre, niveles);
                niveles[Posicion].agregarJugador(Posicion, new Player(prmNickName, prmNombre, this.niveles));
                this.validadoStrings[Posicion]=vecPlayers[Posicion].getNickname();
                return true;
            }else{
                return false;
            }
        }
        return false;
    }
    public void inicializarVecValidar() {
        for (int i = 0; i < validadoStrings.length; i++) {
            this.validadoStrings[i]="-";
        }
    }
    public void i() {
        for (int i = 0; i < validadoStrings.length; i++) {
            System.out.println(validadoStrings[i]);
        }
    }

    public void mostrarEspaciosLibresLevel() {
        for (int i = 0; i < niveles.length; i++) {
            if (niveles[i]==null) {
                System.out.println("Posicion "+ i + ".------------------------vacio----------------------");

            }else{
                System.out.println("Posicion "+i+".---"+niveles[i].getIdLevel()+"-----Puntos para ganar----------"+ niveles[i].getPuntosWin()+"-------------");
            }
        }
    }
    public void llenarVectorNiveles() {
        int contLevel = 5;
        for (int i = 0; i < niveles.length; i++) {
            niveles[i] = new Level(i, contLevel);
            contLevel = contLevel + 10;
        }
    }
    public TypeEnemy tipoEnemigo() {
        int val =0;
        boolean bandera2 = true;
        do {
            System.out.println("elija el tipo de enemigo");
            System.out.println("1.--"+TypeEnemy.ABSTRACTO+"---------");
            System.out.println("2.--"+TypeEnemy.JEFE+"---------");
            System.out.println("3.--"+TypeEnemy.MAGICO+"---------");
            System.out.println("4.--"+TypeEnemy.OGRO+"---------");
            System.out.println("------------------------------");
            val = Integer.parseInt(teclado.nextLine());


            switch (val) {
                case 1:
                        return TypeEnemy.ABSTRACTO;

                case 2:
                        return TypeEnemy.JEFE;
                case 3:
                        return TypeEnemy.MAGICO;
                case 4:
                        return TypeEnemy.OGRO;

                default:
                    break;
            }

        } while (bandera2 = true);

        return TypeEnemy.ABSTRACTO;
    }

    public int contarEnemigos() {
        int contEnemigos = 0;
        for (int i = 0; i < niveles.length; i++) {
            contEnemigos = contEnemigos+niveles[i].contEnemigos();
        }
        return contEnemigos;
    }
    public int contarTesoros() {

        for (int i = 0; i < niveles.length; i++) {
            this.contTesoros = this.contTesoros+niveles[i].getContTesoros();
        }
        return contTesoros;
    }
    public void IncrementarNivel(int prmNivel, int prmJugador) {
        if (jugadores[prmJugador].getPuntajeInicial() >= this.niveles[prmNivel].getPuntosWin()) {
            niveles[prmNivel].agregarJugador(prmNivel, jugadores[prmJugador]);
        }else{
            int h = this.niveles[prmNivel].getPuntosWin()-jugadores[prmJugador].getPuntajeInicial();
            System.out.println("No tienes los puntos necesarion, te falan"+ h + "puntos para pasar");
        }
    }
    public void iniciarJugadoresPrimer(int prmPosicion) {

            if (jugadores[prmPosicion]!=null) {
                if (niveles[0].getJugadoresNivel(prmPosicion)==null){
                    niveles[0].agregarJugador(prmPosicion, jugadores[prmPosicion]);
                }


            }
    }
    public void mostrarJugadoresPorNivel() {
        for (int i = 0; i < niveles.length; i++) {
            for (int j = 0; j < jugadores.length; j++) {
                if (jugadores[j]!=null) {
                    if (niveles[i].buscarJugadoresPosicion(jugadores[j].getNickname() )!= -1) {
                        System.out.println("El jugador" + jugadores[j].getNickname() +" esta en el nivel  "  );
                    }

                }
            }
        }
    }

/*    public void IncrementarNivel(int prmNivel, int prmJugador, int pNivelActual) {
        if (jugadores[prmJugador].getPuntajeInicial() >= this.niveles[prmNivel].getPuntosWin()) {
            niveles[pNivelActual].eliminarJugador(jugadores[prmJugador].getNickname());
            niveles[prmNivel].agregarJugador(prmNivel, jugadores[prmJugador]);
        }else{
            int h = this.niveles[prmNivel].getPuntosWin()-jugadores[prmJugador].getPuntajeInicial();
            System.out.println("No tienes los puntos necesarion, te falan"+ h + "puntos para pasar");
        }
    } */


    public int contarTotalTesoros(String prmNombreTesoro) {
        int cont =0;
        for (int i = 0; i < niveles.length; i++) {
            cont = cont + niveles[i].tesorosIguales(prmNombreTesoro);

        }return cont;
    }
    public int contarTotalTipoEnmigos(TypeEnemy prmTipoEnemigo) {
        int cont =0;
        for (int i = 0; i < niveles.length; i++) {
            cont = cont + niveles[i].tipoEnemigoIgual(prmTipoEnemigo);

        }return cont;
    }
    public void topPlayers() {
        Player aux;
        for(int i = 0; i < jugadores.length; i++){
			for(int j=i+1; j < jugadores.length; j++){
				if(jugadores[i].getPuntajeInicial() < jugadores[j].getPuntajeInicial()){
					aux = jugadores[i];
					jugadores[i] = jugadores[j];
					jugadores[j] = aux;
				}
			}
		}
    }
    public void VecEnemigoConMasPuntos() {

        for (int i = 0; i < niveles.length; i++) {
            if (niveles[i].enemigoConMasPuntos()!=null){
                valEnemigos[i] = niveles[i].enemigoConMasPuntos();
            }

        }

    }
    public void inicializarVecValidarEnemigos() {
        for (int i = 0; i < valEnemigos.length; i++) {
            valEnemigos[i] = new Enemy("-----", 00, 1, TypeEnemy.JEFE,"--");
        }
    }
    public Enemy masPuntosEnemigos() {
        Enemy aux;
        for(int i = 0; i < valEnemigos.length; i++){
			for(int j=i+1; j < valEnemigos.length; j++){

                    if(valEnemigos[i].getSumScore() < valEnemigos[j].getSumScore()){
                        aux = valEnemigos[i];
                        valEnemigos[i] = valEnemigos[j];
                        valEnemigos[j] = aux;
                    }



			}
		}return valEnemigos[0];
    }
    public int uBicarNivel(){
        for (int i = 0; i < niveles.length; i++) {
            if (niveles[i].encontrarPuntaje(masPuntosEnemigos().getSumScore()) == true) {
                return i;
            }
        }return -1;
    }
    public int contarConsonantes() {
        int cont = 0;
        for (int i = 0; i < niveles.length; i++) {
            cont = cont + niveles[i].contarCaracterNombreEnemigo();
        }return cont;
    }
    public void VecTesorosMasRepetidos() {

        for (int i = 0; i < niveles.length; i++) {
            if (niveles[i].tesosroMasRepetido()!=null){
                valTreasures[i] = niveles[i].tesosroMasRepetido();
            }

        }

    }
    public Treasure ordenarTesorosRepetidos() {
        Treasure aux;
        for(int i = 0; i < valTreasures.length; i++){
			for(int j=i+1; j < valTreasures.length; j++){
                if (valTreasures[i]!=null && valTreasures[j] != null) {
                    if(valTreasures[i].getNombre().equals(valTreasures[j].getNombre())){
                        aux = valTreasures[i];
                        valTreasures[i] = valTreasures[j];
                        valTreasures[j] = aux;
                    }

                }

			}
		}return valTreasures[0];
    }
    public void inicializarVecValidarTesoros() {
        int cont = 0;
        for (int i = 0; i < valEnemigos.length; i++) {
            cont = cont+1;
            valTreasures[i] = new Treasure("--",Double.toString(Math.random() * 1280) , 0);
        }
    }

    public Treasure tesoroMasRepetidoPorNivel(int index) {
        int masRepetido = 0;
        int indexMasRepetido = -1;
        int numTesoros = niveles[index].getContTesoros();

        if(numTesoros == 0){
            return null;
        }

        for(int i = 0; i < numTesoros; i++) {
            int contador = 0;
            for(int j = 0; j < numTesoros; j++) {
                if(niveles[index].getTesoros()[i].getNombre().equals(niveles[index].getTesoros()[j].getNombre())) {
                    contador++;
                }
            }
            if(contador > masRepetido) {
                masRepetido = contador;
                indexMasRepetido = i;
            }
        }
        return niveles[index].getTesoros()[indexMasRepetido];
    }

    public String VecTesorosMasRepetidosPorNivel() {
        for (int i = 0; i < niveles.length; i++) {
            if (tesoroMasRepetidoPorNivel(i)!=null){
                valTreasures[i] = tesoroMasRepetidoPorNivel(i);
            }

        }

        int contAux = 0;
        for(int i = 0; i < valTreasures.length; i++){
            if(valTreasures[i] != null){
                break;
            }else{
                contAux++;
            }
        }

        if(contAux == valTreasures.length){
            return "No hay tesoros";
        }

        int masRepetido = 0;
        int indexMasRepetido = -1;
        int numTesoros = valTreasures.length;

        for(int i = 0; i < numTesoros; i++){
            int contador = 0;
            if(valTreasures[i] == null){
                continue;
            }
            for(int j = 0; j < numTesoros; j++){
                if(valTreasures[j] == null){
                    continue;
                }
                if(valTreasures[i].getNombre().equals(valTreasures[j].getNombre())){
                    contador++;
                }
            }
            if(contador > masRepetido){
                masRepetido = contador;
                indexMasRepetido = i;
            }
        }

        
        return valTreasures[indexMasRepetido].getNombre();
    }
}
