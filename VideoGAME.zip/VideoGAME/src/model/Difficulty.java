package model;

/**
 *
 * @author David
 */
public enum  Difficulty {
    //se toma la dificultad como una enumeracion, ya que estos valores no cambiarám

    LOW, MEDIUM, HIGH;

}
