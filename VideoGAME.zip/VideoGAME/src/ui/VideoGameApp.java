package ui;


import model.VideoGame;

/**
 *
 * @author David
 */
public class VideoGameApp {
        public static void main(String[] args) {
        VideoGame vg = new VideoGame();

        System.out.println("Presione enter cada vez que desee continuar");
        vg.desplegarMenu();

    }
}
